package Business;

import Presentation.Login;

public class Main{
	
	public static void main(String args[]){
		SGE s = new SGE();
		new Login(s);
	}
}