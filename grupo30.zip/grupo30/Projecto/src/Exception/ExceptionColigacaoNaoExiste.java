package Exception;

@SuppressWarnings("serial")
public class ExceptionColigacaoNaoExiste extends Exception{
	public ExceptionColigacaoNaoExiste(){super();}
	public ExceptionColigacaoNaoExiste(String message){super(message);}
}
