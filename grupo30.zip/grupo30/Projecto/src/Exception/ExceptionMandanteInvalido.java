package Exception;

@SuppressWarnings("serial")
public class ExceptionMandanteInvalido extends Exception{

	public ExceptionMandanteInvalido() {
		super();
	}

	public ExceptionMandanteInvalido(String message) {
		super(message);
	}

}
