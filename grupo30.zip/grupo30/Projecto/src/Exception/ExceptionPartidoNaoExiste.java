package Exception;

@SuppressWarnings("serial")
public class ExceptionPartidoNaoExiste extends Exception{
	public ExceptionPartidoNaoExiste(){super();}
	public ExceptionPartidoNaoExiste(String message){super(message);}
}
