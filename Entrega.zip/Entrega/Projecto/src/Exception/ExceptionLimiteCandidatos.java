package Exception;

@SuppressWarnings("serial")
public class ExceptionLimiteCandidatos extends Exception{

	public ExceptionLimiteCandidatos() {
		super();
	}
	public ExceptionLimiteCandidatos(String message){
		super(message);
	}
}
