package Exception;

@SuppressWarnings("serial")
public class ExceptionListaNaoExiste extends Exception{
	public ExceptionListaNaoExiste(){super();}
	public ExceptionListaNaoExiste(String message){super(message);}
}
