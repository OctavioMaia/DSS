package Exception;

@SuppressWarnings("serial")
public class ExceptionIniciarEleicao extends Exception{
	public ExceptionIniciarEleicao(){super();}
	public ExceptionIniciarEleicao(String message){super(message);}
}
