package Exception;

@SuppressWarnings("serial")
public class ExceptionCandidatoExiste extends Exception{
	public ExceptionCandidatoExiste(){super();}
	public ExceptionCandidatoExiste(String message){super(message);}
}
