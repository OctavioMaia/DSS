package Exception;

@SuppressWarnings("serial")
public class ExceptionColigacaoExiste extends Exception{
	public ExceptionColigacaoExiste(){super();}
	public ExceptionColigacaoExiste(String message){super(message);}
}
