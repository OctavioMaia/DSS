package Exception;

@SuppressWarnings("serial")
public class ExceptionPartidoExiste extends Exception{
	public ExceptionPartidoExiste(){super();}
	public ExceptionPartidoExiste(String message){super(message);}
}
