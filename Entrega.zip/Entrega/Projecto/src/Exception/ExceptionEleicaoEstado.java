package Exception;

@SuppressWarnings("serial")
public class ExceptionEleicaoEstado extends Exception{
	public ExceptionEleicaoEstado(){super();}
	public ExceptionEleicaoEstado(String message){super(message);}
}
