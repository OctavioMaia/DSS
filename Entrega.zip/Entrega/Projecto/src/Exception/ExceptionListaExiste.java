package Exception;

@SuppressWarnings("serial")
public class ExceptionListaExiste extends Exception{
	public ExceptionListaExiste(){super();}
	public ExceptionListaExiste(String message){super(message);}
}
