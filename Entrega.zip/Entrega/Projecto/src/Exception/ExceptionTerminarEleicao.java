package Exception;

@SuppressWarnings("serial")
public class ExceptionTerminarEleicao extends Exception{
	public ExceptionTerminarEleicao(){super();}
	public ExceptionTerminarEleicao(String message){super(message);}
}
