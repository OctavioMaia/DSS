package Exception;

@SuppressWarnings("serial")
public class ExceptionEleicaoAtiva extends Exception{
	public ExceptionEleicaoAtiva(){super();}
	public ExceptionEleicaoAtiva(String message){super(message);}
}
